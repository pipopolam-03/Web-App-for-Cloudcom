const modalLinks = document.querySelectorAll(".modal-link");

modalLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
        event.preventDefault();
        const targetModal = event.target.getAttribute("href");
        document.querySelector(targetModal).style.display = "block";
    });
});

const closeModals = document.querySelectorAll(".close");

closeModals.forEach((close) => {
    close.addEventListener("click", () => {
        const parentModal = close.closest(".modal");
        parentModal.style.display = "none";
    });
});
