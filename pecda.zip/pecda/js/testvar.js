coins = Math.floor(Math.random() * 100);
stars = Math.floor(Math.random() * 100);
const task = "Бегит";
const name = "Иванов И.И.";
document.getElementById("coins").innerHTML = coins;
document.getElementById("stars").innerHTML = stars;
document.getElementById("name").innerHTML = name;
document.getElementById("task1").innerHTML = task;
