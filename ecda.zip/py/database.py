import base64

import psycopg2

def connect_to_postgresql():
    try:
        connection = psycopg2.connect(
            host='localhost',
            user='postgres',
            password='pipopolam',
            database='web_app_cloudcom'

        )
        print("Подключение к PostgreSQL успешно!")
        return connection
    except psycopg2.Error as err:
        print(f"Ошибка подключения к PostgreSQL: {err}")
        return None


def find_user(connection, username, password):
    try:
        cursor = connection.cursor()

        cursor.execute("SELECT id_user, admin, phane_number, email, position, name_user FROM \"user\" WHERE \"login\" = %s AND \"password\" = %s", (username, password))

        user = cursor.fetchone()
        if user:
            return user
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None


def get_rating_info(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT stars, coins FROM rating WHERE id = %s", (user_id,))
        rating_info = cursor.fetchone()
        if rating_info:
            return rating_info
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None


def get_user_tasks(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT id_task FROM \"user-tasks\" WHERE id_user = %s", (user_id,))

        user_tasks = cursor.fetchall()
        return user_tasks
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None

def get_task(connection, task_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT name_task, comment, date_drop, stars, coins FROM tasks WHERE id = %s", (task_id,))
        task_info = cursor.fetchone()
        if task_info:
            return {
                'name_task': task_info[0],
                'comment': task_info[1],
                'date_drop': str(task_info[2]),  # Преобразование в строку для передачи в JSON
                'stars': task_info[3],
                'coins': task_info[4]
            }
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None

def get_user_rating(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT stars, coins FROM rating WHERE id = %s", (user_id,))
        rating_info = cursor.fetchone()
        cursor.execute("SELECT name_user FROM \"user\" WHERE \"id_user\" = %s", (user_id,))
        name = cursor.fetchone()

        if rating_info:
            return {
                'name': name[0],
                'coins': rating_info[0],
                'stars': rating_info[1]
            }
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None


def get_shop_data(connection):
    cursor = connection.cursor()
    cursor.execute("SELECT id, name_stuff, in_stock, prace, img FROM shop")
    rows = cursor.fetchall()
    shop_data = []
    for row in rows:
        row_list = list(row)
        item = {
            "id": row_list[0],
            "name_stuff": row_list[1],
            "in_stock": row_list[2],
            "prace": row_list[3],
            "img": None  # Изначально устанавливаем значение как None
        }
        if row_list[4]:  # Проверяем, что данные изображения не пусты
            img_data = row_list[4].tobytes()
            item["img"] = base64.b64encode(img_data).decode('utf-8')
        shop_data.append(item)
    cursor.close()
    return shop_data

def get_active_tasks(connection):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT name_task FROM tasks WHERE date_finish IS NULL")
        task_rows = cursor.fetchall()

        if task_rows:
            return {
                'name_task': task_rows[0]
            }
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None


def purchase(connection, user_id, username, cart_data):
    try:
        cursor = connection.cursor()

        total_price = 0
        for item in cart_data:
            # Получаем цену товара из базы данных
            cursor.execute("SELECT prace FROM shop WHERE id = %s", (item['id'],))
            price = cursor.fetchone()[0]
            total_price += price * item['quantity']

            # Обновляем количество товара в таблице shop (уменьшаем на количество купленных товаров)
            cursor.execute("UPDATE shop SET in_stock = in_stock - %s WHERE id = %s", (item['quantity'], item['id']))

            # Добавляем запись о покупке в таблицу stuff
            cursor.execute("INSERT INTO stuff (date, user_id, stuff_id) VALUES (CURRENT_DATE, %s, %s)",
                           (user_id, item['id']))

        # Уменьшаем количество монет пользователя в таблице rating
        cursor.execute("UPDATE rating SET coins = coins - %s WHERE id_user = %s", (total_price, user_id))

        connection.commit()
        return True, "Покупка успешно выполнена"
    except psycopg2.Error as err:
        connection.rollback()
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return False, "Ошибка при выполнении покупки"

