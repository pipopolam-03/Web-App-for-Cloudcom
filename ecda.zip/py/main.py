import json
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import database

class RequestHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', 'http://localhost:63343')
        self.end_headers()

        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        form = urllib.parse.parse_qs(post_data.decode('utf-8'))

        print("Username:", form['username'][0])
        print("Password:", form['password'][0])

        connection = database.connect_to_postgresql()
        if connection:
            user_data = database.find_user(connection, form['username'][0], form['password'][0])
            if user_data:
                user_id, admin_flag, phone_number, email, position, fullname = user_data  # Разбираем кортеж
                print(f"Пользователь найден. ID пользователя: {user_id}, Флаг админа: {admin_flag}, Имя: {fullname}")
                rating_info = database.get_rating_info(connection, user_id)
                coins, stars = rating_info
                task_info_list = []
                if rating_info:
                    stars, coins = rating_info

                # Вызываем функцию rating для получения всех пар [пользователь, звезды]
                rating = database.rating(connection)
                print(rating)

                if admin_flag == 0:

                    response = {
                        'admin': admin_flag,
                        'id': user_id,
                        'stars': stars,
                        'coins': coins,
                        'phone': phone_number,
                        'email': email,
                        'position': position,
                        'fullname': fullname,
                        'rating': rating  # Список пар [пользователь, звезды]
                    }

                elif admin_flag == 1:  # Если пользователь - администратор
                    tasks = [1]
                    if tasks:
                        for user_id in tasks:
                            task_rows = database.get_active_tasks(connection)
                            if task_rows:
                                task_info_list.append(task_rows)
                            else:
                                print(f"Не удалось получить информацию о задаче с ID {user_id}")

                        # Формируем JSON-объект для отправки клиенту
                    print(task_info_list)

                    response = {
                        'admin': admin_flag,
                        'id': user_id,
                        'stars': stars,
                        'coins': coins,
                        'phone': phone_number,
                        'email': email,
                        'position': position,
                        'fullname': fullname,
                        'rating': rating,  # Список пар [пользователь, звезды]
                        'tasks': task_info_list
                    }

                try:
                    response_json = json.dumps(response)
                    self.wfile.write(bytes(response_json, 'utf-8'))
                except Exception as e:
                    print("Ошибка при сериализации объекта в JSON:", e)

            else:
                print("Пользователь не найден.")
            connection.close()



    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()


    def do_GET(self):
            if self.path == '/get_shop_data':
                # Обработка GET-запроса для получения данных о магазине
                connection = database.connect_to_postgresql()
                if connection:
                    shop_data = database.get_shop_data(connection)
                    if shop_data:
                        self.send_response(200)
                        self.send_header('Content-type', 'application/json')
                        self.send_header('Access-Control-Allow-Origin', 'http://localhost:63343')
                        self.end_headers()
                        self.wfile.write(bytes(json.dumps(shop_data), 'utf-8'))
                    else:
                        self.send_error(500, 'Internal Server Error')
                    connection.close()
                else:
                    self.send_error(500, 'Internal Server Error')
            else:
                self.send_error(404, 'Not Found')
def run(server_class=HTTPServer, handler_class=RequestHandler, port=16342):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    httpd.timeout = 10
    print(f"Сервер запущен на порту {port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()