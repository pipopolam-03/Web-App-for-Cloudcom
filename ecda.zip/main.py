import json
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import database

class RequestHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', 'http://localhost:63343')
        self.end_headers()

        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        form = urllib.parse.parse_qs(post_data.decode('utf-8'))

        print("Username:", form['username'][0])
        print("Password:", form['password'][0])

        connection = database.connect_to_postgresql()
        if connection:
            user_data = database.find_user(connection, form['username'][0], form['password'][0])
            if user_data:
                user_id, admin_flag = user_data  # Разбираем кортеж
                print(f"Пользователь найден. ID пользователя: {user_id}, Флаг админа: {admin_flag}")
                rating_info = database.get_rating_info(connection, user_id)
                name = database.get_user_name(connection, user_id)
                if rating_info:
                    stars, coins = rating_info

                response = {'admin': admin_flag, 'id': user_id, 'stars': stars, 'coins': coins, 'name': name}
                self.wfile.write(bytes(json.dumps(response), 'utf-8'))

                user_tasks = database.get_user_tasks(connection, user_id)
                if user_tasks:
                    print("Названия задач пользователя:")
                    for task_id in user_tasks:
                        task_name = database.get_task_name(connection, task_id[0])
                        if task_name:
                            print(task_name)
                        else:
                            print(f"Задача с id {task_id[0]} не найдена.")
                else:
                    print("Задания пользователя не найдены.")
            else:
                print("Пользователь не найден.")
            connection.close()


    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

def run(server_class=HTTPServer, handler_class=RequestHandler, port=16342):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    httpd.timeout = 10
    print(f"Сервер запущен на порту {port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
