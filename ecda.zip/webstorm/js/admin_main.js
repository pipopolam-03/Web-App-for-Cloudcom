const userData = JSON.parse(localStorage.getItem('userData'));
const ratingArrayString = userData.rating;
const userDataString = localStorage.getItem('adminData');

const ShopstarsElement = document.getElementById('main-admin-stars');
ShopstarsElement.textContent = userData.stars;

const ShopcoinsElement = document.getElementById('main-admin-coins');
ShopcoinsElement.textContent = userData.coins;

const ShopnameElement = document.getElementById('main-admin-name');
ShopnameElement.textContent = userData.fullname;

try {
    const ratingArray = JSON.parse(ratingArrayString);

    const ratingTableBody = document.querySelector('.rating-panel tbody');

    // Очищаем таблицу перед добавлением новых данных
    ratingTableBody.innerHTML = '';

    // Перебираем массив рейтинга пользователей и добавляем их в таблицу
    ratingArray.forEach((user, index) => {
        const row = document.createElement('tr');
        const placeCell = document.createElement('td');
        const usernameCell = document.createElement('td');
        const pointsCell = document.createElement('td');

        placeCell.textContent = index + 1;
        usernameCell.textContent = user.name;
        pointsCell.textContent = user.stars;

        row.appendChild(placeCell);
        row.appendChild(usernameCell);
        row.appendChild(pointsCell);

        ratingTableBody.appendChild(row);
    });
} catch (error) {
    console.error('Ошибка при парсинге данных о рейтинге:', error);
}

if (userDataString) {
    try {
        const userData = JSON.parse(userDataString);
        console.log('userData:', userData);

        const tasksArray = userData.tasks;

        const taskTableBody = document.getElementById('task-table-body');

        // Очищаем таблицу перед добавлением новых данных
        taskTableBody.innerHTML = '';

        // Перебираем массив задач и добавляем их в таблицу
        tasksArray.forEach(task => {
            const row = document.createElement('tr');
            const tasknameCell = document.createElement('td');

            tasknameCell.textContent = task.name_task; // Предполагается, что task.name_task содержит массив и нужно использовать первый элемент

            row.appendChild(tasknameCell);

            taskTableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Ошибка при парсинге данных из локального хранилища:', error);
    }
} else {
    console.error('Данные о задачах не найдены в localStorage');
}