const userData = JSON.parse(localStorage.getItem('userData'));

if (userData) {
    // Отображаем количество звезд и монет
    const ShopstarsElement = document.getElementById('stars-shop');
    ShopstarsElement.textContent = userData.stars;

    const ShopcoinsElement = document.getElementById('coins-shop');
    ShopcoinsElement.textContent = userData.coins;

    const ShopnameElement = document.getElementById('name-shop');
    ShopnameElement.textContent = userData.fullname;
}
