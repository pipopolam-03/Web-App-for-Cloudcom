// Получаем данные пользователя из локального хранилища
const userData = JSON.parse(localStorage.getItem('userData'));
const tasksArrayString = userData.tasks;
try {
    // Распарсим данные о задачах из строки JSON
    const tasksArray = JSON.parse(tasksArrayString);

    // Получим ссылку на элемент списка задач
    const tasksList = document.querySelector('.tasks ul');

    // Очистим список перед добавлением новых данных
    tasksList.innerHTML = '';

    // Переберем массив задач и добавим каждую задачу в список
    tasksArray.forEach(task => {
        // Создаем элемент списка для задачи
        const taskListItem = document.createElement('li');

        // Устанавливаем текстовое содержимое элемента списка
        taskListItem.textContent = task.name_task;

        // Добавляем элемент списка в список задач
        tasksList.appendChild(taskListItem);
    });
} catch (error) {
    console.error('Ошибка при парсинге данных о задачах:', error);
}

// Проверяем, что данные есть в локальном хранилище
if (userData) {
    // Отображаем количество звезд и монет
    const starsElement = document.getElementById('stars');
    starsElement.textContent = userData.stars;

    const coinsElement = document.getElementById('coins');
    coinsElement.textContent = userData.coins;

    const positionElement = document.getElementById('position');
    positionElement.textContent = userData.position;

    const emailElement = document.getElementById('email');
    emailElement.textContent = userData.email;

    const phoneElement = document.getElementById('phone');
    phoneElement.textContent = userData.phone;

    const nameElement = document.getElementById('fullname');
   nameElement.textContent = userData.fullname;

    const bignameElement = document.getElementById('bigfullname');
    bignameElement.textContent = userData.fullname;

    const newnameElement = document.getElementById('new_fullname');
    newnameElement.textContent = userData.fullname;

    // Отображаем ID пользователя в заголовке
    const userIdElement = document.getElementById('UserId');
    userIdElement.textContent = userData.id;

    const usersRating = JSON.parse(localStorage.getItem('usersRating'));
    const tableBody = document.getElementById('rating-table-body');

// Очищаем содержимое таблицы
    tableBody.innerHTML = '';

// Проходимся по каждой паре [пользователь, звезды] и добавляем их в таблицу
    usersRating.forEach(pair => {
        const row = document.createElement('tr');

        const userNameCell = document.createElement('td');
        userNameCell.textContent = pair[0]; // Имя пользователя
        row.appendChild(userNameCell);

        const starsCell = document.createElement('td');
        starsCell.textContent = pair[1]; // Количество звезд
        row.appendChild(starsCell);

        // Добавляем строку в таблицу
        tableBody.appendChild(row);
    });

} else {
    console.error('User data not found in localStorage');
}
