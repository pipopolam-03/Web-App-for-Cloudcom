const userData = JSON.parse(localStorage.getItem('userData'));
const tasksArrayString = userData.tasks;
const ratingArrayString = userData.rating;

try {
    console.log(typeof userData.rating);
    const ratingArray = JSON.parse(ratingArrayString);

    const ratingTableBody = document.getElementById('rating-table-body');

    // Очищаем таблицу перед добавлением новых данных
    ratingTableBody.innerHTML = '';

    // Перебираем массив рейтинга пользователей и добавляем их в таблицу
    ratingArray.forEach(user => {
        const row = document.createElement('tr');
        const usernameCell = document.createElement('td');
        const starsCell = document.createElement('td');
        const coinsCell = document.createElement('td');

        usernameCell.textContent = user.name;
        coinsCell.textContent = user.coins; // Замените 'username' на свойство, содержащее имя пользователя
        starsCell.textContent = user.stars; // Замените 'stars' на свойство, содержащее количество звезд

        row.appendChild(usernameCell);
        row.appendChild(coinsCell);
        row.appendChild(starsCell);

        ratingTableBody.appendChild(row);
    });
} catch (error) {
    console.error('Ошибка при парсинге данных о рейтинге:', error);
}


try {
    // Попытаемся преобразовать строку обратно в объект JSON
    const tasksArray = JSON.parse(tasksArrayString);

    const nameMainElement = document.getElementById('name_main');
    nameMainElement.textContent = userData.fullname

    const starsElement = document.getElementById('stars');
    starsElement.textContent = userData.stars;

    const coinsElement = document.getElementById('coins');
    coinsElement.textContent = userData.coins;

    // Проверяем, является ли tasksArray массивом
    if (Array.isArray(tasksArray)) {
        tasksArray.forEach((task, index) => {
            // Проверяем наличие названия задачи
            if (task.name_task) {
                // Создаем id для каждой карточки
                const taskId = `name_task_${index + 1}`;
                const taskNameElement = document.getElementById(taskId);

                // Проверяем, существует ли элемент с id
                if (taskNameElement) {
                    taskNameElement.textContent = task.name_task;
                } else {
                    console.error(`Элемент с id ${taskId} не найден.`);
                }

                // Создаем id для каждого модального окна задачи
                const modalTaskId = `modal_task_${index + 1}`;
                const modalTask = document.getElementById(modalTaskId);

                // Проверяем, существует ли модальное окно задачи
                if (modalTask) {
                    // Добавляем название задачи в модальное окно
                    const modalTaskNameElement = modalTask.querySelector('h1');
                    if (modalTaskNameElement) {
                        modalTaskNameElement.textContent = task.name_task;
                    } else {
                        console.error(`Элемент h1 в модальном окне с id ${modalTaskId} не найден.`);
                    }

                    // Добавляем комментарий к задаче в модальное окно
                    const modalTaskCommentElement = modalTask.querySelector('p');
                    if (modalTaskCommentElement) {
                        modalTaskCommentElement.textContent = task.comment || '...';
                    } else {
                        console.error(`Элемент p в модальном окне с id ${modalTaskId} не найден.`);
                    }
                } else {
                    console.error(`Модальное окно с id ${modalTaskId} не найдено.`);
                }
            } else {
                console.error(`Отсутствует название задачи для задачи с индексом ${index}.`);
            }
        });
    } else {
        console.error('Ошибка: Данные о задачах отсутствуют или имеют неверный формат.');
    }
} catch (error) {
    console.error('Ошибка при парсинге данных о задачах:', error);
}
