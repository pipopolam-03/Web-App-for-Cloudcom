var k = 0;
const username = localStorage.getItem('username');
const password = localStorage.getItem('password');

async function addToCart(productName, price) {
    var cart = document.getElementById('cart');
    var totalElement = document.getElementById('total');
    var existingItem = findCartItem(productName);

    if (existingItem) {
        k = 1;
        updateQuantity(existingItem.querySelector('.quantity-input'), 1);
    } else {
        var listItem = document.createElement('li');
        listItem.textContent = productName + ' - ' + price.toFixed(2) + '¤';
        var removeButton = document.createElement('button');
        removeButton.textContent = 'Удалить';
        removeButton.className = 'remove-button';
        removeButton.setAttribute('data-product', productName);
        removeButton.onclick = function () {
            removeFromCart(productName, price);
        };
        listItem.appendChild(removeButton);
        cart.appendChild(listItem);
        var currentTotal = parseFloat(totalElement.textContent);
        totalElement.textContent = (currentTotal + price).toFixed(2);
        var quantityInput = document.createElement('input');
        quantityInput.type = 'number';
        quantityInput.value = 1;
        quantityInput.min = 1;
        quantityInput.className = 'quantity-input';
        quantityInput.readOnly = true;
        var addButton = document.createElement('button');
        addButton.textContent = '+';
        addButton.className = 'quantity-button';
        addButton.onclick = function () {
            k = 1;
            updateQuantity(quantityInput, 1);
        };
        var subtractButton = document.createElement('button');
        subtractButton.textContent = '-';
        subtractButton.className = 'quantity-button';
        subtractButton.onclick = function () {
            k = -1;
            updateQuantity(quantityInput, -1);
        };
        listItem.appendChild(subtractButton);
        listItem.appendChild(quantityInput);
        listItem.appendChild(addButton);

        try {
            // Получаем имя пользователя из локального хранилища
            const username = localStorage.getItem('username');

            // Отправляем информацию о покупке на сервер, включая имя пользователя
            const response = await fetch('http://localhost:16342/purchase', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    productName: productName,
                    price: price,
                    username: username  // Добавляем имя пользователя в данные
                })
            });

            if (!response.ok) {
                throw new Error('Ошибка при совершении покупки');
            }

            // Получаем текущее количество звёзд из локального хранилища
            const starsElement = document.getElementById('stars-shop');
            const currentStars = parseInt(starsElement.textContent);

            // Получаем общую стоимость покупки из корзины
            const totalElement = document.getElementById('total');
            const totalCost = parseFloat(totalElement.textContent);

        } catch (error) {
            console.error('Ошибка при выполнении покупки:', error);
            alert('Произошла ошибка при выполнении покупки');
        }
    }
}


async function removeFromCart(productName, price) {
    var listItem = findCartItem(productName);
    if (listItem) {
        var quantity = parseInt(listItem.querySelector('.quantity-input').value);
        listItem.parentNode.removeChild(listItem);
        var totalElement = document.getElementById('total');
        var currentTotal = parseFloat(totalElement.textContent);
        totalElement.textContent = (currentTotal - price * quantity).toFixed(2);
    }
}

async function clearCart() {
    var cart = document.getElementById('cart');
    var totalElement = document.getElementById('total');

    while (cart.firstChild) {
        cart.removeChild(cart.firstChild);
    }

    totalElement.textContent = '0.00';
}

function updateQuantity(quantityInput, change) {
    var newQuantity = parseInt(quantityInput.value) + change;
    if (newQuantity < 1) {
        newQuantity = 1;
        k = 0;
    }
    quantityInput.value = newQuantity;
    updateTotal(quantityInput);
}

function updateTotal(quantityInput) {
    var listItem = quantityInput.parentNode;
    var price = parseFloat(listItem.textContent.match(/([\d.]+)¤/)[1]);
    var quantity = parseInt(quantityInput.value);
    var totalElement = document.getElementById('total');
    var currentTotal = parseFloat(totalElement.textContent);
    if (k === 1) {
        totalElement.textContent = (currentTotal - price * (quantity - 1) + (price * quantity)).toFixed(2);
    } else if (k === 0) {
        totalElement.textContent = (currentTotal - price * (quantity - 1)).toFixed(2);
    }
    if (k === -1) {
        totalElement.textContent = (currentTotal - price).toFixed(2);
    }
}

var products = []; // Массив продуктов, который будет заполнен из базы данных

function displayProducts(products) {
    var cardsContainer = document.getElementById('cards-container');
    cardsContainer.innerHTML = ''; // Очищаем контейнер перед добавлением новых продуктов

    if (products.length === 0) {
        var noProductMessage = document.createElement('p');
        noProductMessage.textContent = 'Нет доступных продуктов';
        cardsContainer.appendChild(noProductMessage);
    } else {
        products.forEach(function (product) {
            var card = document.createElement('div');
            card.classList.add('card');

            var title = document.createElement('h2');
            title.textContent = product.name_stuff;
            card.appendChild(title);

            var image = document.createElement('img');
            image.src = 'data:image/jpeg;base64,' + product.img;
            image.alt = 'Product';
            card.appendChild(image);

            var price = document.createElement('p');
            price.classList.add('price');
            price.textContent = product.prace.toFixed(2) + ' ¤'; // Здесь обращаемся к свойству prace для отображения цены
            card.appendChild(price);

            var addButton = document.createElement('button');
            addButton.textContent = 'Добавить';
            addButton.onclick = function () {
                addToCart(product.name_stuff, product.prace); // Передаем имя и цену продукта в функцию addToCart
            };
            card.appendChild(addButton);

            cardsContainer.appendChild(card);
        });
    }
}

// Функция загрузки продуктов из базы данных
async function loadProductsFromDatabase() {
    try {
        const response = await fetch('http://localhost:16342/get_shop_data', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error('Не удалось загрузить продукты');
        }

        const data = await response.json();
        console.log(data);
        products = data;
        displayProducts(products); // Вызываем функцию displayProducts для отображения продуктов на странице
    } catch (error) {
        console.error('Ошибка загрузки продуктов:', error);
    }

}

function sortItems(order) {
    var sortedProducts = products.slice();

    if (order === 'asc') {
        sortedProducts.sort(function (a, b) {
            return a.prace - b.prace;
        });
    } else if (order === 'desc') {
        sortedProducts.sort(function (a, b) {
            return b.prace - a.prace;
        });
    }

    displayProducts(sortedProducts);
}

function resetSort() {
    displayProducts(products);
}

function findCartItem(productName) {
    var cartItems = document.getElementById('cart').getElementsByTagName('li');
    for (var i = 0; i < cartItems.length; i++) {
        if (cartItems[i].textContent.includes(productName)) {
            return cartItems[i];
        }
    }
    return null;
}

loadProductsFromDatabase(); // Вызов функции загрузки продуктов при загрузке страницы