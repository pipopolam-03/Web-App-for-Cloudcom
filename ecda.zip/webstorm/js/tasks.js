document.addEventListener('DOMContentLoaded', function() {
    const addTaskModal = document.getElementById('add-task-modal');
    const addTaskButton = document.getElementById('add-task-button');
    const taskList = document.getElementById('task-list');

    // Массив для хранения задач
    const tasks = [];

    // Функция для отображения списка задач
    function displayTaskList() {
        // Очищаем список перед обновлением
        taskList.innerHTML = '';

        // Добавляем каждую задачу в список
        tasks.forEach((task, index) => {
            const taskItem = document.createElement('div');
            taskItem.classList.add('task-item');
            taskItem.innerHTML = `
                <span>${task}</span>
                <button class="add-subtask-button">+</button>
            `;
            taskList.appendChild(taskItem);

            // Добавляем обработчик события для кнопки "+"
            const addButton = taskItem.querySelector('.add-subtask-button');
            addButton.addEventListener('click', function() {
                // Добавляем подзадачу (здесь ваш код)
                console.log('Добавление подзадачи для задачи ' + index);
            });
        });
    }

    // Обработчик события для открытия модального окна добавления задачи
    addTaskButton.addEventListener('click', function() {
        addTaskModal.style.display = 'block';
    });

    // Обработчик события для добавления задачи
    addTaskButton.addEventListener('click', function() {
        const taskNameInput = document.getElementById('task-name');
        const taskName = taskNameInput.value.trim();
        if (taskName !== '') {
            // Добавляем задачу в массив и обновляем список задач
            tasks.push(taskName);
            displayTaskList();
            // Закрываем модальное окно
            addTaskModal.style.display = 'none';
            // Очищаем поле ввода
            taskNameInput.value = '';
        }
    });

    // Закрытие модального окна по нажатию на крестик
    addTaskModal.querySelector('.close').addEventListener('click', function() {
        addTaskModal.style.display = 'none';
    });

    // Отображаем список задач при загрузке страницы
    displayTaskList();
});
