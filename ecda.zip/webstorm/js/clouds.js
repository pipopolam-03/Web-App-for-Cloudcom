
    document.addEventListener("DOMContentLoaded", function(event) {
    var body = document.querySelector('body');
    var initialX = 0;
    var initialY = 0;
    var amplitude = 50; // Амплитуда синусоиды
    var speed = 0.05; // Скорость движения

    function moveBackground() {
    var newY = initialY + amplitude * Math.sin(speed * initialX);
    body.style.backgroundPosition = initialX + "px " + newY + "px";
    initialX+=0.08;
    requestAnimationFrame(moveBackground);
}

    moveBackground();
});
