// Выбираем все карточки
let cards = document.querySelectorAll('.card');

// Выбираем модальное окно
let modal_task = document.getElementById('task');

// Добавляем событие click на каждую карточку
cards.forEach(card => {
    card.addEventListener('click', function() {
        // Открываем модальное окно
        modal_task.style.display = 'block';
    });
});

// Функция для закрытия модальных окон
function closeModal() {
    modal.style.display = 'none';
    modal_task.style.display = 'none';
}

// Добавляем обработчик события для закрытия модальных окон при клике вне них
window.addEventListener('click', (event) => {
    if (event.target === modal || event.target === modal_task) {
        closeModal();
    }
});

