document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:16342/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        console.log(data);

        if (data.admin === 0) {
            localStorage.setItem('userData', JSON.stringify({
                id: data.id,
                coins: data.coins,
                stars: data.stars,
                admin: data.admin,
                phone: data.phone,
                email: data.email,
                fullname: data.fullname,
                position: data.position
            }));
            window.location.href = 'main.html';
        } else if (data.admin === 1) {
            const adminData = {
                id: data.id,
                coins: data.coins,
                stars: data.stars,
                admin: data.admin,
                phone: data.phone,
                email: data.email,
                fullname: data.fullname,
                position: data.position,
                tasks: data.tasks || [] // Handle case when tasks are not available
            };
            localStorage.setItem('adminData', JSON.stringify(adminData));
            window.location.href = 'admin_main.html';
        } else {

        }
    } catch (error) {
        console.error(error);
        // Handle error, show appropriate message to the user
    }
});
