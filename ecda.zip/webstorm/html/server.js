const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mysql = require('mysql');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'pipopolam',
    database: 'my_bd'
});

connection.connect((error) => {
    if (error) throw error;
    console.log('Connected to database');
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM person WHERE username = ? AND password = ?';
    connection.query(query, [username, password], (error, results) => {
        if (error) throw error;
        if (results.length > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    });
});

app.listen(63342, () => {
    console.log(`Server is running on ${63342}`);
});