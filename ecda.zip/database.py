import psycopg2

def connect_to_postgresql():
    try:
        connection = psycopg2.connect(
            host='localhost',
            user='postgres',
            password='Hi123789',
            database='web_app_cloudcom'

        )
        print("Подключение к PostgreSQL успешно!")
        return connection
    except psycopg2.Error as err:
        print(f"Ошибка подключения к PostgreSQL: {err}")
        return None


def find_user(connection, username, password):
    try:
        cursor = connection.cursor()

        cursor.execute("SELECT id_user, admin FROM \"user\" WHERE \"login\" = %s AND \"password\" = %s", (username, password))

        user = cursor.fetchone()
        if user:
            return user
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None

def get_rating_info(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT stars, coins FROM rating WHERE id = %s", (user_id,))
        rating_info = cursor.fetchone()
        if rating_info:
            return rating_info
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None


def get_user_tasks(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT id_task FROM \"user-tasks\" WHERE id_user = %s", (user_id,))

        user_tasks = cursor.fetchall()
        return user_tasks
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None

def get_task_name(connection, task_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT name_task FROM tasks WHERE id = %s", (task_id,))
        task_name = cursor.fetchone()
        if task_name:
            return task_name[0]
        else:
            return None
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None

def get_user_name(connection, user_id):
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT name_user FROM \"user\" WHERE id_user = %s", (user_id,))
        name = cursor.fetchall()
        if name:
            return name
        else:
            return "None"
    except psycopg2.Error as err:
        print(f"Ошибка при выполнении запроса к базе данных: {err}")
        return None