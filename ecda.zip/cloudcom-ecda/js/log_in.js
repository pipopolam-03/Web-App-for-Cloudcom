document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:16342/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        console.log(data);

        // Сохраняем данные в локальном хранилище
        localStorage.setItem('userData', JSON.stringify({
            id: data.id,
            coins: data.coins,
            stars: data.stars,
            admin: data.admin,
            name: data.name,
            username: username
        }));

        console.log(name);
        console.log('sjhfbghjslb');

        localStorage.setItem('userId', data.id);
        if (data.admin === 0) {
            window.location.href = 'main.html';
        } else {
            window.location.href = 'admin_main.html';
        }
    } catch (error) {
        console.error(error);
    }
});
