// Получаем данные пользователя из локального хранилища
const userData = JSON.parse(localStorage.getItem('userData'));

// Проверяем, что данные есть в локальном хранилище
if (userData) {
    // Отображаем количество звезд и монет
    const starsElement = document.getElementById('stars');
    starsElement.textContent = userData.stars;

    const coinsElement = document.getElementById('coins');
    coinsElement.textContent = userData.coins;

    // Отображаем ID пользователя в заголовке
    const userIdElement = document.getElementById('UserId');
    userIdElement.textContent = userData.id;

    // Отображаем имя пользователя
    const nameElement = document.getElementById('name');
    nameElement.textContent = userData.name;

} else {
    console.error('User data not found in localStorage');
}
